/**************page swich and step code***************************/
(function($) {
    "use strict";
    function verificationForm() {
        var current_fs, next_fs, left, opacity, scale, animating;
        $(".next, .previous").click(function () {
            if (animating) return false;
            animating = true;
            current_fs = $(this).parent();
            next_fs = $(this).hasClass("next") ? current_fs.next() : current_fs.prev();
            $("#progressbar li").eq($("fieldset").index(next_fs)).addClass("active");
            next_fs.show();
            current_fs.animate({
                opacity: 0
            }, {
                step: function (now, mx) {
                    scale = 1 - (1 - now) * 0.2;
                    left = (now * 50) + "%";
                    opacity = 1 - now;
                    next_fs.css({'left': left,'opacity': opacity});
                },
                duration: 800,
                complete: function () {
                    current_fs.hide();
                    animating = false;
                },
                easing: 'easeInOutBack'
            });
        });
        $(".submit").click(function () {
            return false;
        });
    };
    verificationForm();
})(jQuery);
/**************tab link for billpay page***************************/
  function openTab(tabId) {
    var tabContents = document.getElementsByClassName('tab-content');
    for (var i = 0; i < tabContents.length; i++) {
      tabContents[i].style.display = 'none';
    }
    var tabs = document.getElementsByClassName('tab');
    for (var i = 0; i < tabs.length; i++) {
      tabs[i].classList.remove('active');
    }
    document.getElementById(tabId).style.display = 'block';
    document.querySelector('.tab[data-tab="' + tabId + '"]').classList.add('active');
  }
  
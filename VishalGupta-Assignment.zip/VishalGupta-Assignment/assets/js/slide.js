function moveToSlide(slideIndex) {
    $('#demo').carousel(slideIndex);
}
/********Remove active class when click on back button***********************/
$(document).ready(function () {
    $(".previous_button").on("click", function () {
        var currentStep = $(".multi_step_form #msform #progressbar li.active");
        currentStep.removeClass("active");
        currentStep.prev("li").addClass("active");
    });
});
/**************Delete when click on delete button***************************/
$(document).ready(function () {
    $(".delete-btn").on("click", function () {
        $(this).closest(".pro-box").remove();
        var deleteMeCount = $(".pro-box").length;
        $("#continue-btn").prop("disabled", deleteMeCount === 0);
    });
});